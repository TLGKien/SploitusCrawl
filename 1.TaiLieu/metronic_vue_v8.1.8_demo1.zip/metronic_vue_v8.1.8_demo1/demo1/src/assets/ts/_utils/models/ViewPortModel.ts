export interface ViewPortModel {
  width: number;
  height: number;
}
